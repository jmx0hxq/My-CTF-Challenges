<?php
/**
 * Created by PhpStorm.
 * User: hookover
 * Date: 17-10-16
 * Time: 下午3:38
 */

namespace App\Repositories;

use App\Models\File;
use Illuminate\Support\Str;

class DecodeLogRepository extends BaseRepository
{

}