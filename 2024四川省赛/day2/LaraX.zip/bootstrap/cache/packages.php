<?php return array (
  'appzcoder/crud-generator' => 
  array (
    'providers' => 
    array (
      0 => 'Appzcoder\\CrudGenerator\\CrudGeneratorServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'overtrue/laravel-lang' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelLang\\TranslationServiceProvider',
    ),
  ),
  'overtrue/laravel-ueditor' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelUEditor\\UEditorServiceProvider',
    ),
  ),
  'spatie/laravel-menu' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Menu\\Laravel\\MenuServiceProvider',
    ),
    'aliases' => 
    array (
      'Menu' => 'Spatie\\Menu\\Laravel\\Facades\\Menu',
    ),
  ),
  'yansongda/laravel-pay' => 
  array (
    'providers' => 
    array (
      0 => 'Yansongda\\LaravelPay\\PayServiceProvider',
    ),
    'aliases' => 
    array (
      'Pay' => 'Yansongda\\LaravelPay\\Facades\\Pay',
    ),
  ),
);