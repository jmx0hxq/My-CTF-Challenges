<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link href="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/css/bootstrap.css" rel="stylesheet" />
	<link href="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/css/feedback_custom.css" rel="stylesheet" />
	<link href="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/css/index_custom.css" rel="stylesheet">

	<script src="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/js/bootstrap.js" type="text/javascript"></script>
    <script src="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/js/feedback_custom.js" type="text/javascript"></script>
</head>
<body class="fixed-background-feedback">
<div class="container">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
                <div class="sheet-box-feedback sheet-box">
                    <a href="http://www.creative-tim.com">
                    <div class="logo-container">
                        <div class="logo">
                            <img src="http://demos.creative-tim.com/paper-kit-2-pro/examples/js/images/tim_logo.png">
                        </div>
                        <div class="brand">
                            Creative Tim
                        </div>
                    </div>
                    </a>
                    <div class="clearfix"></div>
                <legend></legend>
                <h4>

                    <a href="http://demos.creative-tim.com/landing-page"> Awesome Landing Page</a>
                <br />
                    <a href="http://demos.creative-tim.com/navbar-with-icons"> Bootstrap Navbar With Icons</a>
                <br />
                    <a href="http://demos.creative-tim.com/wizard-demo-register"> Bootstrap Wizard</a>
                <br />
					<a href="http://demos.creative-tim.com/material-bootstrap-wizard/wizard-book-room.html"> Material Bootstrap Wizard</a>
				<br />
					<a href="http://demos.creative-tim.com/paper-bootstrap-wizard/wizard-list-place.html"> Paper Bootstrap Wizard</a>
				<br />
                    <a href="http://demos.creative-tim.com/coming-sssoon-demo-image-background"> Coming Sssoon Pages</a>
                <br />
                    <a href="http://demos.creative-tim.com/datepicker"> Datepicker </a>
                <br />
                    <a href="http://demos.creative-tim.com/dribbble-rotating-card"> Dribbble Rotating Card</a>
                <br />
                    <a href="http://demos.creative-tim.com/feedback">Feedback Form</a>
                <br />
                    <a href="http://demos.creative-tim.com/fresh-bootstrap-table"> Fresh Bootstrap Table</a>
                <br />
                    <a href="http://demos.creative-tim.com/fullcalendar"> Full Calendar</a>
                <br />
                    <a href="http://demos.creative-tim.com/get-shit-done/index.html">Get Shit Done Kit</a>
                <br />
                    <a href="http://demos.creative-tim.com/hipster-as-f-cards"> Hipster As F*** Cards</a>
                <br />
                    <a href="http://demos.creative-tim.com/light-bootstrap-dashboard"> Light Bootstrap Dashboard</a>
                <br />
                    <a href="http://demos.creative-tim.com/login-register"> Login/Register Modal </a>
                <br />
                    <a href="http://demos.creative-tim.com/material-kit/index.html"> Material Kit </a>
				<br />
					<a href="http://demos.creative-tim.com/material-dashboard/examples/dashboard.html"> Material Dashboard </a>
				<br />
					<a href="http://demos.creative-tim.com/material-dashboard-pro/examples/dashboard.html"> Material Dashboard PRO</a>
				<br />
                    <a href="http://demos.creative-tim.com/paper-dashboard/dashboard.html"> Paper Dashboard </a>
				<br />
				    <a href="http://demos.creative-tim.com/paper-dashboard-pro/examples/dashboard/overview.html"> Paper Dashboard PRO</a>
				<br />
                    <a href="http://demos.creative-tim.com/paper-kit"> Paper Kit</a>
				<br />
                    <a href="http://demos.creative-tim.com/paper-kit-pro/presentation.html">Paper Kit Pro</a>
                <br />
                    <a href="http://demos.creative-tim.com/rotating-card"> Rotating Card</a>
				<br />
					<a href="http://demos.creative-tim.com/gaia-bootstrap-template/freebie.html"> Gaia Bootstrap Template Demo</a>
                <br />
					<a href="http://demos.creative-tim.com/gaia-bootstrap-template-pro/index.html"> Gaia Bootstrap Template Pro</a>
				<br />
                </h4>
                </div>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46172202-1', 'auto');
  ga('send', 'pageview');

</script>

<!-- Hotjar Tracking Code for demos.creative-tim.com -->
<script>
    (function(f,b){
        var c;
        f.hj=f.hj||function(){(f.hj.q=f.hj.q||[]).push(arguments)};
        f._hjSettings={hjid:31000, hjsv:4};
        c=b.createElement("script");c.async=1;
        c.src="//static.hotjar.com/c/hotjar-"+f._hjSettings.hjid+".js?sv="+f._hjSettings.hjsv;
        b.getElementsByTagName("head")[0].appendChild(c);
    })(window,document);
</script>


</body>
</html>
