<?php

namespace app\controller;

use app\BaseController;
class Xctf extends BaseController
{
    public function hecker()
    {
        unserialize(base64_decode($_POST['pop']));
    }
}