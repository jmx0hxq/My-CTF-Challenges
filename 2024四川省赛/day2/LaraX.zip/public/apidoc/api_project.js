define({
  "name": "API文档",
  "version": "0.1.0",
  "description": "图形识别API接口文档",
  "title": "图形识别API接口文档",
  "url": "http://api.AI.com",
  "sampleUrl": "http://api.AI.com",
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-11-06T12:54:52.385Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
