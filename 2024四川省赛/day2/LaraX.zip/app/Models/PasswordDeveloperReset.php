<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PasswordDeveloperReset extends Model
{
    //
}
